# Precision of the matched-subset reference medians

The finite number of matched-subset draws introduces Monte Carlo uncertainty into the excess-departure estimates in Table S1. Begin with `control_reference_resource_precision.tsv` for the two resource reductions and their simultaneous Monte Carlo bounds. `control_reference_patient_precision.tsv` reports every evaluable patient's corresponding quantities; `control_reference_map_precision.tsv` contains all 407 primary configurations and both reference medians.

Excess-departure estimates and bounds are in section stromal-score MAD units. `gap_mc_low` and `gap_mc_high` bound the size-matched minus location-matched excess. Positive values indicate a lower excess after location matching. The precision bounds condition on the observed tissue, readout and maps. The resource gap is a difference between two resource medians; the patient gap is a difference between that patient's two summaries.

Supporting Methods describes the order-statistic bounds and their aggregation. Table S1 reports variation among patients and the effect of omitting each patient from the resource summaries.
