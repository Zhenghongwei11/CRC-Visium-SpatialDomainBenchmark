# Composition, domain, and reference-model sensitivity data

This directory contains ten groups of 49 scientific TSV/TSV.gz tables from complementary analyses of the existing spatial transcriptomic sections. The source resources comprise 14 Valdeolivas sections from 7 patients and 8 GSE294385 sections from 5 patients. Patient denominators vary by analysis and remain in the tables.

## Table groups

- **Coverage-qualified domains** summarize selection coverage, within-setting readout contrasts, and patient-level hierarchical summaries.
- **Domain marker context** reports single-gene panels, feature availability, gene-level context, population support, and realized patient denominators. The 53 candidate markers are presented individually; no composite marker score is constructed. TPSAB1 and TPSB2 are unavailable in some GSE294385 sections and remain missing in the corresponding records.
- **Qualified-domain composition** describes model-derived composition summaries for the fixed populations. Where a source lacks the required composition model output, values remain NA rather than being set to zero.
- **Continuous support** reports eligibility and feature-balance diagnostics, shared targets, weighted group shares, marginal distribution comparisons, and region-weight diagnostics.
- **Continuous profiles** provides patient-level weighted-profile results and same-patient comparisons under common and stricter support definitions.
- **Residual conditional chain** contains availability, contrasts, matched-reference comparisons, patient/resource summaries, finite patient denominators, reference-degeneracy records, and the common-case index for the two added controls.
- **RCTD continuous support** contains model-availability inputs, case eligibility, feature-balance and target summaries, weighted group shares, marginal KS diagnostics, region-weight diagnostics, and the saved model-derived weights used in these sensitivity calculations.
- **RCTD continuous profiles** reports patient-level weighted-profile results and same-patient control comparisons, together with common-finite-patient and stricter-distribution summaries.
- **Outside-direct-fit feature sensitivity** reports panel membership/counts and patient/resource summaries for profiles defined over the outside-direct-fit feature universe. It is a feature-universe sensitivity, not independent validation.
- **Native RCTD model summaries** give section- and stratum-level summaries of the fitted native model outputs.

## Scope and definitions

The RCTD-derived tables are model-conditional sensitivities based on the same spatial RNA measurements used for the expression readouts. They do not provide independent validation, measured physical cell fractions, or evidence of cell identity. The 23 reference-panel donors are reference donors, not spatial patients, and do not increase the spatial patient denominators.

The calibration targets and `group_aggregate_shares` summaries use spot-level calibration weights. Pooled RNA profiles normalize weighted original counts by their full-feature weighted library mass, so each spot's RNA contribution also depends on its library size. Spot-weighted moment balance does not certify equal library-weighted mixture contributions.

Across the strict-KS common-finite-patient summaries, the number of common spatial patients is zero in both resources; the associated comparisons are unavailable and remain NA. This records a lack of shared finite support, not a zero effect or a successful strict-support result.

In the native-model tables, `lambda_centre_over_observed_total` is the native log-noise-zero count-centre ratio. It is not an expected count, a fitted-accuracy score, or an exact marginal expectation. Rank and correlation fields are descriptive.

For the C/LC common-support comparison, the common-case table contains 70 patient–configuration rows covering 4 patients. Rows, sections, configurations, and repeated measurements are not independent patients; the patient is the unit for patient-level summaries. NA denotes unavailable or undefined information, including unsupported estimates, and is not equivalent to zero. These descriptive analyses do not establish causal composition effects, cell identity, or independent validation.
