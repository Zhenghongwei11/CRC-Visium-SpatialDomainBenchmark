# Table S4: paired readout-feature withholding

The paired fits completed on 2026-10-07 compare tissue selection and regional expression when TGFB1, CXCL12, ACTA2 and TAGLN are allowed or withheld from map fitting. Expression k-means, coordinate-augmented k-means, Ward and Leiden use the same tissue bands and expression outcome in both versions. For the paired numerical comparison, begin with `resource_summary.tsv` and `patient_summary.tsv`, choosing `frame=common_configurations`. The `arm_specific` frame separately includes all configurations eligible in each arm.

Across available mapped-domain pairs, patient-level Jaccard overlap has a median of 0.928 in Valdeolivas and 0.963 in GSE294385. Within configurations eligible in both arms, location-matched excess changes from 0.092 to 0.035 MAD in Valdeolivas and from 0.150 to 0.152 in GSE294385. High overlap of selected stroma accompanies a reduced location-matched departure in Valdeolivas and a similar departure in GSE294385. The comparison assesses direct feature inclusion in these four fitted methods; both versions retain the observed expression correlations and tissue composition.

The paired regional comparison contains 76 common evaluable configurations in Valdeolivas and 128 in GSE294385, spanning five patients per resource. Jaccard and adjusted Rand measurements use a broader fit/mapping denominator. Missing overlap values indicate unavailable fits or domain mappings. Arm-specific summaries include all configurations with sufficient regional tissue in that version. These summaries can therefore include more settings than the paired comparison. Configurations and sections are repeated measurements within patients.

| File | Scientific contents |
| --- | --- |
| `map_results.tsv` | All 1,056 declared fitting attempts, actual features, fit and regional availability, regional contrasts and matched departures |
| `paired_map_results.tsv` | All 528 paired configurations, common eligibility, whole-map adjusted Rand index, selected-stroma and band Jaccard overlap, and within-pair numerical changes |
| `section_summary.tsv` | Every attempted section and arm in both reporting frames |
| `patient_summary.tsv` | All 12 attempted patients, with successive equal-weight summaries within patient and explicit unavailable values |
| `resource_summary.tsv` | Separate resource medians and their patient, section and configuration denominators |
| `availability.tsv` | All declared settings grouped by fit status, regional status and unavailable reason |
| `sections/` | Complete feature universes, PCA scores, fitted labels, registered measurements, selected masks, control draws |

Section arrays connect the measured regional expression with the input features, fitted labels and retained tissue. The whole-domain stroma mask includes annotated stromal spots outside the near/far bands, so its overlap describes a broader tissue selection than the regional contrast.

Fitting, normalization, sampling and aggregation are described in Supporting Methods.
