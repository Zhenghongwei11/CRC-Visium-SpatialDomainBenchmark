# Supporting tables and figure source data

The tables connect the annotated tissue with its domain-selected expression contrast, then examine patient variation, component genes, domain fitting and spatial sampling. Figs 1–2 introduce the comparison; Figs S1 and S3 place its expression patterns in tissue; Fig S7 examines direct feature inclusion.

The current tables use nominal Visium array distances. Main Table 1 is `current_table1.tsv`. Baseline estimates use array-coordinate six-nearest-neighbor connectivity; exact hexagonal adjacency provides a separate graph sensitivity. The two resources are summarized separately. Maps and serial sections are repeated measurements within patients.

## Tables

Tables S1–S19 are supplied as individual workbooks in `../SUPPLEMENTARY_TABLES/`. Original TSV files and section-level scientific arrays remain available below.

[Table legends](TABLE_LEGENDS.md) describe the comparisons; the [field dictionary](TABLE_FIELD_DICTIONARY.tsv) defines columns, units and missing values. Tables S6–S8 also include a Field_dictionary worksheet for their source data.

| Table | Contents | Files |
| --- | --- | --- |
| S1 | All attempted patients: primary patient summaries and reference-map sensitivity | `primary_patient_summary.tsv`; `configuration_location_matching_summary.tsv`; `patient_leave_one_out.tsv`; `diagnostic_patient_summary.tsv` |
| S2 | Registered case tissue, all-section contractile markers, block contributions and annotation coverage | `case_section_geometry.tsv`; `case_block_contributions.tsv`; `source_label_coverage.tsv`; `contractile_marker_section_summary.tsv`; `contractile_marker_block_summary.tsv`; `contractile_marker_spots.tsv.gz` |
| S3 | Original-count recovery, barcode and feature coverage, normalization and score recomposition for all 22 sections | `component_source_recovery.tsv` |
| S4 | Paired new fits allowing or withholding readout genes: complete attempts, common/arm-specific summaries, overlap and features | [Complete table files and section-level arrays](readout_withholding/README.md) |
| S5 | Corrected primary estimates, intervals and support-margin sensitivity across graphs and spatial settings; comparison of coordinate conventions | `corrected_full_effects.tsv`; `real_threshold_sensitivity.tsv`; `setting_status_summary.tsv`; `geometry_result_reconciliation.tsv` |
| S6 | Pure-domain screening and fine-clustering/merging settings | `pure_domain_selection/` |
| S7 | Broad regional profiles, patient comparisons and technical matching | `regional_profiles/` |
| S8 | Model-derived composition, coverage and dominant-group controls | `inferred_composition/` |
| S9 | Seven readouts' expression distributions, zero-MAD status and patient/resource summaries | `component_expression_summary.tsv`; `regional_patient_sensitivity.tsv`; `regional_resource_summary.tsv` |
| S10 | All attempted sections, corrected band measurement requirements, full-band contrasts and section denominators | `anchor_section_summary.tsv`; `corrected_anchor_all_settings.tsv`; `diagnostic_section_summary.tsv` |
| S11 | Baseline contrasts and controls under own-band and reference-map requirements | `current_per_map_results.tsv`; `diagnostic_map_diagnostic.tsv`; `diagnostic_status_summary.tsv`; `diagnostic_method_k_summary.tsv` |
| S12 | Full 36,960-row sensitivity grid and successive equal-weight summaries | `regional_map_sensitivity.tsv`; `regional_historical_restricted_method_k_sensitivity.tsv`; `regional_historical_restricted_section_sensitivity.tsv`; `regional_historical_restricted_patient_sensitivity.tsv`; `regional_independent_eligible_method_k_sensitivity.tsv`; `regional_independent_eligible_section_sensitivity.tsv`; `regional_independent_eligible_patient_sensitivity.tsv` |
| S13 | Whole-domain stromal-fraction screening at 0, 0.50 and 0.75, with counts under both regional requirements | `primary_stromal_fraction_summary.tsv`; `diagnostic_purity_sensitivity.tsv`; `regional_purity_sensitivity.tsv` |
| S14 | Whole-domain geometry for all changed primary alternatives, including partially overlapping and disjoint selections | `domain_repartitioning_summary.tsv` |
| S15 | Five spatial settings and both sets of regional measurement requirements, with complete patient/section/map denominators and both graphs | `spatial_scale_summary.tsv`; `graph_band_membership_summary.tsv` |
| S16 | Wider 175-µm near-band measurements, memberships, full-band intervals and same-map comparisons | `wider_near_map_results.tsv`; `wider_near_anchor_intervals.tsv`; `wider_near_patient_summary.tsv`; `wider_near_resource_summary.tsv`; `wider_near_membership.tsv`; `near_band_map_comparison.tsv`; `near_band_common_map_summary.tsv` |
| S17 | Patient-level regional representation by map family, with separate contrast/geometry denominators and clustering parameters | `method_selection_comparison.tsv`; `map_producer_parameters.tsv` |
| S18 | Shared versus separately sampled block intervals for all original full-band comparisons | `common_block_intervals.tsv` |
| S19 | Known-boundary simulation: all realizations, condition summaries, calibration and support margins | `simulation_summary.tsv`; `simulation_cell_metrics.tsv`; `simulation_calibration_by_map.tsv`; `simulation_threshold_sensitivity.tsv` |

Table S11 contains 1,680 baseline map and selection-rule combinations. Table S5 contains 16,800 rows from the same grid crossed with two graphs and five spatial settings. Table S12 adds six component readouts at baseline to give 36,960 rows. Rows with unavailable estimates give the reason. The primary comparison requires sufficient near and far tissue in the selected map itself. This own-band requirement defines `status` in `current_per_map_results.tsv`. The reference-map sensitivity in `diagnostic_map_diagnostic.tsv` also requires a calculable default-map comparison. Baseline own-band contrasts and controls are in the four-gene, array-coordinate six-neighbor subset of Table S12. Paired reference comparisons require sufficient spots and blocks in both maps.

Zero stromal MAD leaves standardized quantities undefined. Expression-unit contrasts and controls remain available wherever geometric support is sufficient. Positive-expression fractions and component distributions accompany sparse-readout medians in Table S9.

Table S1 shows patient variation alongside map-level changes and the effect of omitting each patient from the resource summaries.

## Figures

Plotted values and spot positions are in `figure_source_data/`. `figure_source_data/complete_figure_manifest.json` identifies the source files and image exports for all fourteen figures.

- Fig 1: `figure1_spots.tsv` and its scale record.
- Fig 2: `figure2_panel_A.tsv` through `figure2_panel_D.tsv`.
- Fig 3: `figure3_data_1.tsv`, `figure3_data_2.tsv`, `figure3_data_3.tsv`, `figure3_data_4.tsv` and `figure3_data_5.tsv`.
- Fig S1: `figureS1_spots.tsv.gz` and `figureS1_sections.tsv`.
- Fig S2: `figureS2_panel_A.tsv` and `figureS2_panel_B.tsv`.
- Fig S3: `figureS3_spots.tsv.gz` and `source_label_coverage.tsv`.
- Fig S4: `figureS4_panel_A.tsv` through `figureS4_panel_D.tsv`.
- Fig S5: `figureS5_panel_source.tsv`.
- Fig S6: `figureS6_panel_A.tsv` through `figureS6_panel_D.tsv`.
- Fig S7: `figureS7_A_feature_incidence.tsv`, `figureS7_B_patient_overlap.tsv` and `figureS7_C_D_patient_excess.tsv`; full inputs are in Table S4.
- Fig S8: `figureS8_data_1.tsv` and `figureS8_data_2.tsv`.
- Fig S9: `figureS9_data_1.tsv` and `figureS9_data_2.tsv`.
- Fig S10: `figureS10_panel_A.tsv` and `figureS10_panel_B.tsv`.
- Fig S11: `figureS11_panel_A.tsv` through `figureS11_panel_C.tsv`.

Registered image overlays retain the original image coordinates. Their scale bars represent nominal array distance obtained from the original registration. All five case sections are shown. The supplied M-ST-32 image excludes five original nonstromal coordinates; all stromal-band spots are inside its extent.

## Complete paired-fitting results in Table S4

[Paired-fitting tables and section-level scientific arrays](readout_withholding/README.md) connect each regional comparison to its actual input features, fitted labels and selected tissue. Both common-configuration and arm-specific summaries are retained with their respective denominators. Fitting and measurement procedures are described in Supporting Methods.

## Finite-draw precision accompanying Table S1

The [precision tables](control_reference_precision/README.md) show how uncertainty from a finite number of subset draws propagates to the map, patient and resource reference summaries. These bounds condition on the observed tissue, expression and maps. Their construction is described in Supporting Methods.

## Domain-refit sensitivity

The [domain-refit sensitivity tables](domain_refit_sensitivity/README.md) compare archived and refitted partitions, location-matching summaries and wider-band results on shared evaluable maps. They retain the map and patient denominators for each comparison.

## Additional contractile markers in Table S2

MYH11, CNN1 and DES measurements cover all 22 sections. Section summaries describe all annotated stroma and each band; block and spot tables locate the contributing expression. The original band definitions remain fixed.

## Table terminology

The [field-name map](TABLE_FIELD_NAME_MAP.tsv) connects reader-facing table terms with the original calculation keys. The [field dictionary](TABLE_FIELD_DICTIONARY.tsv) gives their scientific definitions, units and missing-value conventions.

## Regional profiles and modeled composition

Tables S6–S8 contain purity and coverage, broad regional profiles, and model-derived composition, respectively. Their scientific source tables are in `pure_domain_selection/`, `regional_profiles/` and `inferred_composition/`. Profile-difference units and the original four-gene section-MAD units are distinct. See the table legends for denominators and missing values.

Fig 3 draws from Table S7. Fig S8 draws from Table S6, Fig S9 from Table S8, and Fig S10 shows simulations from Table S19. Plotted source extracts for all figures are supplied in `figure_source_data/`.

## Conditional composition and fixed-domain context

The [composition-sensitivity collection](composition_sensitivity/) supplies 49 scientific source tables in ten groups: coverage-qualified domain selection, single-gene tissue-context panels, source-label eight-group author-model summaries, continuous support and profile analyses, residual conditional references, RCTD-derived continuous support and profiles, outside-direct-fit feature-universe sensitivity, and native-model section/stratum summaries. The 53 candidate tissue-context markers are reported individually, without a composite score. Whole domains and annotated-stroma intersections remain separate. Broad-profile scaled differences use the fixed resource gene scale; four-gene excess uses expression units and separately stromal MAD units. Every component retains its actual finite spatial-patient denominator; unavailable models, failed common support and zero-MAD summaries remain unavailable. All RCTD-derived results are same-RNA model-conditional sensitivities; they do not establish independent validation, physical cell fractions, or cell identity. The strict-KS common-finite-patient summaries contain zero spatial patients in both resources, so those estimates remain NA. The reference panel's 23 donors are not additional spatial patients. In native-model tables, `lambda_centre_over_observed_total` is the native log-noise-zero count-centre ratio, not an expected count, fitted-accuracy score, or exact marginal expectation; rank and correlation summaries are descriptive.

### Source tables for composition and conditional comparisons

- Tissue-context gene detection in coverage-qualified regions: [gene-level summaries](composition_sensitivity/domain_marker_context/GENE_CONTEXT.tsv.gz).
- Author-model composition-moment sensitivity: [patient results](composition_sensitivity/continuous_profiles/weighted_profile_patient_results.tsv) and [resource summaries](composition_sensitivity/continuous_profiles/same_common_patient_resource_summary.tsv).
- Profiles excluding native direct-fit genes: [matched-patient resource summaries](composition_sensitivity/rctd_outside_direct_fit/same_finite_patient_resource_summary.tsv).
- Composition-conditioned domain references: [matched reference comparisons](composition_sensitivity/residual_conditional_chain/matched_reference_comparisons.tsv) and [patient summaries](composition_sensitivity/residual_conditional_chain/patient_summaries.tsv).

## Main Table 2: common-reference comparison

Table 2 presents the common-reference comparison added to the main manuscript. Its model-derived source tables and patient-level comparisons are available in the [composition-sensitivity collection](composition_sensitivity/), including the RCTD profile and native-model groups. These are same-RNA, model-conditional results; the reference-panel donors do not increase spatial patient denominators.

## Main Table 3: purpose-specific region choice

Table 3 adds operational checks and actions when anatomical coverage, domain coverage or comparator support is limited. Its numerical eligibility criteria are specific to this study. Table 3 is a qualitative synthesis of the anatomical-coverage, pure-domain, broad-profile and composition-support results. Its three rows concern anatomical regional averages, expression-defined tissue subsets and reference-tissue comparisons. It adds no new empirical score or validated ranking. Numerical evidence remains in Tables S6–S8 and the composition-sensitivity source collection, with original patient and availability denominators.

The [53-gene tissue-context panel](composition_sensitivity/domain_marker_context/GENE_PANEL.tsv) lists each candidate together with its source identifiers and locators. These candidates provide context for the same spatial RNA measurements.

## Reference subtype groupings

`inferred_composition/subtype_group_crosswalk.tsv` maps the 36 cell2location subtype labels to the descriptive seven-group and source-label eight-group summaries and to the seven-group RCTD reference. The RCTD column records group assignment or exclusion; the reference-cell count is the number of cells sampled for that subtype in the 1,400-cell reference. Source cell types describe deposited annotation labels, not independently established identities.

## RCTD fitting-gene context

`composition_sensitivity/rctd_mesenchymal_marker_fit_membership.tsv` lists native bulk/regression fitting-gene membership for the 20 mesenchymal tissue-context candidates in each of the 22 sections. Membership does not establish the separability of reference populations.
